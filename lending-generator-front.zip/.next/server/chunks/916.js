exports.id = 916;
exports.ids = [916];
exports.modules = {

/***/ 916:
/***/ ((module) => {

// Exports
module.exports = {
	"handle_edit_button": "Reviews_handle_edit_button__2SLFz",
	"add_review_button_wrapper": "Reviews_add_review_button_wrapper__MuGYz",
	"handle_delete_button": "Reviews_handle_delete_button__qePUw",
	"handle_publish_button": "Reviews_handle_publish_button__OVHhG",
	"loader_wrap": "Reviews_loader_wrap__J9_Wn",
	"rotation": "Reviews_rotation__Y_oUv",
	"title_admin_review": "Reviews_title_admin_review__9GX1J",
	"display_reviews": "Reviews_display_reviews__CsLuO",
	"review_title": "Reviews_review_title__RHYv_",
	"main_review_block": "Reviews_main_review_block__1CbGD",
	"review_text_block": "Reviews_review_text_block__XRY_7",
	"review_block": "Reviews_review_block__6iVHe",
	"image_wrap": "Reviews_image_wrap__nw_1W",
	"button_block": "Reviews_button_block__KVh64",
	"review_desc": "Reviews_review_desc__qX1WM",
	"remove_imege_button_wrap": "Reviews_remove_imege_button_wrap__PT5ch",
	"edit_button_wrap": "Reviews_edit_button_wrap__vrcro",
	"edit_input_wrap": "Reviews_edit_input_wrap__MsxSp",
	"arrow_down_wrap": "Reviews_arrow_down_wrap__VeYJX",
	"arrow_down": "Reviews_arrow_down__mPcu5",
	"edit_form": "Reviews_edit_form__QdZLp",
	"new_review_wrap": "Reviews_new_review_wrap__8bd22",
	"admin_review_wrap": "Reviews_admin_review_wrap__KYm2A"
};


/***/ })

};
;