"use strict";
exports.id = 769;
exports.ids = [769];
exports.modules = {

/***/ 4769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9755);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_legacy_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(916);
/* harmony import */ var _styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);





const TemplateDetailReview = ({ review , deleteUrl , updateReviewUrl , updateImageUrl , userReview  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const inputFileRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [isOpen, setIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [imageUrl, setImageUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [imageFile, setImageFile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [rating, setRating] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleDelete = ()=>{
        const defaultUrl = window.location.href; // замініть на фактичний URL
        const id = defaultUrl.split("/").pop(); // отримати останній елемент URL (ID)
        const url = `${deleteUrl}${id}`;
        const options = {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        };
        fetch(url, options);
        setTimeout(()=>{
            router.push("/edit/admin");
        }, 500);
    };
    const handleEdit = ()=>{
        setIsOpen(true);
        setImageUrl(review?.imageUrl);
        setName(review?.name);
        setRating(review?.rating);
        setDescription(review?.description);
        setDate(review?.date);
    };
    const onClickRemoveImage = async (event)=>{
        setImageFile("");
        setImageUrl("");
    };
    const editFetchFunc = ()=>{
        const defaultUrl = window.location.href; // замініть на фактичний URL
        const id = defaultUrl.split("/").pop(); // отримати останній елемент URL (ID)
        const url = `${updateReviewUrl}${id}`;
        const options = {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "name": name,
                "description": description,
                "rating": rating,
                "date": date
            })
        };
        fetch(url, options);
        setIsOpen(false);
        setTimeout(()=>{
            window.location.reload();
        }, 1000);
    };
    const saveUpdateImage = async ()=>{
        try {
            const defaultUrl = window.location.href; // замініть на фактичний URL
            const id = defaultUrl.split("/").pop(); // отримати останній елемент URL (ID)
            if (imageFile == "") {
                const formData = new FormData();
                formData.append("imageUrl", "");
                const response = await fetch(`${updateImageUrl}${id}`, {
                    method: "PATCH",
                    body: formData
                });
                const data = await response.json();
            } else {
                const formData = new FormData();
                formData.append("imageUrl", imageFile);
                const response = await fetch(`${updateImageUrl}${id}`, {
                    method: "PATCH",
                    body: formData
                });
                const data = await response.json();
            }
            setTimeout(()=>{
                window.location.reload();
            }, 1000);
        } catch (error) {
            console.error(error);
        }
    };
    const publish = async (event)=>{
        event.preventDefault();
        try {
            const formData = new FormData();
            formData.append("imageUrl", review?.imageUrl);
            formData.append("name", review?.name);
            formData.append("rating", review?.rating);
            formData.append("description", review?.description);
            formData.append("date", review?.date);
            const response = await fetch("https://lending-generator-server.herokuapp.com/create-comment", {
                method: "POST",
                body: formData
            });
            handleDelete();
            setTimeout(()=>{
                router.push("/edit/admin");
            }, 1000);
        } catch (error) {
            console.error(error);
        }
    };
    const handleFileChange = async (event)=>{
        setImageFile(event.target.files[0]);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().main_review_block),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().review_block),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().image_wrap),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_legacy_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: `${review?.imageUrl != undefined && review?.imageUrl != "null" && review?.imageUrl != "" ? review?.imageUrl : "/image/not-img.jpg"}`,
                            alt: `${review?.imageUrl != undefined && review?.imageUrl != "null" ? review?.imageUrl : "/image/not-img.jpg"}`,
                            width: "100",
                            height: "100",
                            layout: "responsive",
                            objectFit: "cover",
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().image_item)
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().review_text_block),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: review?.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: review?.date ? review?.date : review.createdAt
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                children: [
                                    "Рейтинг: ",
                                    review?.rating
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().review_desc),
                                children: [
                                    "Опис: ",
                                    review?.description
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().edit_form),
                children: isOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().image_wrap),
                    children: [
                        review?.imageUrl ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_legacy_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: `${review?.imageUrl != undefined && review?.imageUrl != "null" && review?.imageUrl != "" ? review?.imageUrl : "/image/not-img.jpg"}`,
                            alt: `${review?.imageUrl}`,
                            width: "100",
                            height: "100",
                            layout: "responsive",
                            objectFit: "cover",
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().image_item)
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: imageUrl ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().remove_imege_button_wrap),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: onClickRemoveImage,
                                    className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_delete_button),
                                    children: " Видалити фото"
                                })
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "file",
                                        onChange: handleFileChange,
                                        ref: inputFileRef,
                                        hidden: true
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().edit_button_wrap),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_edit_button),
                                                onClick: ()=>inputFileRef.current.click(),
                                                children: "Завантажити фото"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: saveUpdateImage,
                                                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_publish_button),
                                                children: "Зберегти"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().edit_input_wrap),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Вкажіть імя"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "text",
                                    value: name,
                                    onChange: (e)=>setName(e.target.value)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Ваш коментар"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    value: description,
                                    onChange: (e)=>setDescription(e.target.value)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Поставте оцінку"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "number",
                                    value: rating,
                                    onChange: (e)=>setRating(e.target.value)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Вкажіть дату"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "date",
                                    value: date,
                                    onChange: (e)=>setDate(e.target.value)
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().edit_button_wrap),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setIsOpen(false),
                                    className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_delete_button),
                                    children: "Закрити"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: editFetchFunc,
                                    className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_edit_button),
                                    children: "Підтвердити"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().button_block),
                children: isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: handleEdit,
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_edit_button),
                            children: "Редагувати"
                        }),
                        userReview && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: publish,
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_publish_button),
                            children: "Опублікувати"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: handleDelete,
                            className: (_styles_admin_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_4___default().handle_delete_button),
                            children: "Видалити"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TemplateDetailReview);


/***/ })

};
;