(() => {
var exports = {};
exports.id = 416;
exports.ids = [416];
exports.modules = {

/***/ 7249:
/***/ ((module) => {

// Exports
module.exports = {
	"handle_delete_button": "Order_handle_delete_button___h3NU",
	"loader_wrap": "Order_loader_wrap__PegkV",
	"rotation": "Order_rotation__Y1I09",
	"title_order": "Order_title_order__kHbgU",
	"order_wrap": "Order_order_wrap__uCMvf",
	"order_block": "Order_order_block__5GdmV",
	"ordr_item_wrap": "Order_ordr_item_wrap__5UgJ4",
	"ordr_item_block": "Order_ordr_item_block__6VIFh"
};


/***/ }),

/***/ 9393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7249);
/* harmony import */ var _styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);




const getStaticPaths = async ()=>{
    const res = await fetch(`https://lending-generator-server.herokuapp.com/get-all-order`);
    const data = await res.json();
    const paths = data.map((order)=>{
        return {
            params: {
                id: `${order._id}`
            }
        };
    });
    return {
        paths,
        fallback: true
    };
};
const getStaticProps = async (context)=>{
    const { id  } = context.params;
    const res = await fetch(`https://lending-generator-server.herokuapp.com/get-one-order/${id}`);
    const data = await res.json();
    return {
        props: {
            order: data
        }
    };
};
const Order = ({ order  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const handleDelete = ()=>{
        const defaultUrl = window.location.href; // замініть на фактичний URL
        const id = defaultUrl.split("/").pop(); // отримати останній елемент URL (ID)
        const url = `https://lending-generator-server.herokuapp.com/remove-order/${id}`;
        const options = {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        };
        fetch(url, options);
        setTimeout(()=>{
            router.push("/edit/admin");
        }, 500);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3___default().ordr_item_wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3___default().title_order),
                children: "Замовлення:"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: order && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3___default().ordr_item_block),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Імя замовника: ",
                                order.name
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Адрес замовника: ",
                                order.adress
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Телефон замовника: ",
                                order.phone
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Комментар замовника: ",
                                order.comment
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    children: "Замовлений товар:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "Про товар: ",
                                        order.selectedorder
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: handleDelete,
                className: (_styles_admin_Order_module_scss__WEBPACK_IMPORTED_MODULE_3___default().handle_delete_button),
                children: "Видалити"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Order);


/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9393));
module.exports = __webpack_exports__;

})();